package com.avtomatorgovli.core.designsystem.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF006782)
val SecondaryOrange = Color(0xFFFF7B1C)
val SuccessGreen = Color(0xFF1EB980)
val ErrorRed = Color(0xFFB00020)
