package com.avtomatorgovli.core.designsystem.theme

import androidx.compose.material3.Typography

val RetailTypography = Typography()
